(() => {
  const key = 'frota.theme';
  const system = matchMedia('(prefers-color-scheme: dark)');
  const root = document.documentElement;
  let saved;
  let button;

  const valid = value => value === 'light' || value === 'dark' ? value : null;
  try { saved = valid(localStorage.getItem(key)); } catch { saved = null; }

  function applyTheme(){
    const dark = saved === 'dark' || (!saved && system.matches);
    root.dataset.theme = dark ? 'dark' : 'light';
    if(button) button.setAttribute('aria-pressed', String(dark));
  }

  applyTheme();
  system.addEventListener('change', applyTheme);
  window.addEventListener('storage', event => {
    if(event.key === key || event.key === null){
      saved = valid(event.newValue);
      applyTheme();
    }
  });

  document.addEventListener('DOMContentLoaded', () => {
    const sidebar = document.querySelector('.user-area');
    const host = sidebar || document.querySelector('.login-shell, .auth-card, .diagnostic');
    if(!host) return;
    button = document.createElement('button');
    button.type = 'button';
    button.className = sidebar ? 'theme-toggle' : 'theme-toggle public-theme-toggle';
    button.setAttribute('aria-label', 'Modo escuro');
    button.title = 'Modo escuro';
    button.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" aria-hidden="true">
      <path class="theme-moon" d="M20.9 14.3A9 9 0 0 1 9.7 3.1a9 9 0 1 0 11.2 11.2Z"/>
      <g class="theme-sun"><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5"/></g>
    </svg>`;
    if(sidebar) sidebar.querySelector('#logout-button').before(button);
    else host.prepend(button);
    button.addEventListener('click', () => {
      saved = root.dataset.theme === 'dark' ? 'light' : 'dark';
      try { localStorage.setItem(key, saved); } catch { /* Mantém a escolha nesta página. */ }
      applyTheme();
    });
    applyTheme();
  });
})();
