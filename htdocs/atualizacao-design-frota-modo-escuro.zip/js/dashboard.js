async function loadPage(){
  const data = await api("resumo");
  const content = document.querySelector("#dashboard-content");
  const date = document.querySelector("#dashboard-date");
  const today = new Date();
  date.dateTime = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,"0")}-${String(today.getDate()).padStart(2,"0")}`;
  date.innerHTML = uiIcon("agenda");
  date.append(new Intl.DateTimeFormat("pt-BR",{weekday:"short",day:"2-digit",month:"short",year:"numeric"}).format(today));
  document.querySelectorAll("[data-shortcut]").forEach(link => {link.hidden = !canRead(link.dataset.shortcut);});

  const cards = Array.isArray(data.cards) ? data.cards : [];
  const trips = Array.isArray(data.abertas) ? data.abertas : null;
  const icons = new Map([["Veículos","veiculos"],["Funcionários","funcionarios"],["Viagens em andamento","viagens"],["Combustível","abastecimentos"],["Manutenção","manutencoes"],["Multas","multas"]]);
  content.innerHTML = `
    ${cards.length ? `<section class="dashboard-metrics" aria-labelledby="metrics-title">
      <div class="dashboard-section-title"><h2 id="metrics-title" class="section-title">Indicadores da frota</h2></div>
      <div class="cards">
        ${cards.map(card => `<article class="card ${card.w ? "warning" : ""}">
          <div class="metric-heading"><span class="metric-icon">${uiIcon(icons.get(card.t))}</span><small>${escapeHtml(card.t)}</small></div>
          <strong>${card.m ? money(card.v) : escapeHtml(card.v)}</strong>
        </article>`).join("")}
      </div>
    </section>` : ""}
    ${trips ? `
      <section class="dashboard-trips" aria-labelledby="trips-title">
      <div class="dashboard-panel-heading">
        <div class="dashboard-section-title"><h2 id="trips-title" class="section-title">Viagens em andamento</h2>
          <span class="trip-count">${trips.length} ${trips.length === 1 ? "viagem" : "viagens"}</span></div>
        ${canRead("viagens") ? '<a href="viagens.html">Ver todas as viagens <span aria-hidden="true">↗</span></a>' : ""}
      </div>
      <div class="table-wrap" tabindex="0" role="region" aria-labelledby="trips-title">
        <table class="dashboard-table">
          <thead><tr><th>Veículo</th><th>Motorista</th><th>Rota</th><th>Saída</th></tr></thead>
          <tbody>${trips.length ? trips.map(trip => `<tr><td>${escapeHtml(trip.veiculo)}</td><td>${escapeHtml(trip.func)}</td><td>${escapeHtml(trip.origem)} → ${escapeHtml(trip.destino)}</td><td>${escapeHtml(dateValue(trip.saida))}</td></tr>`).join("") : '<tr><td colspan="4" class="empty">Nenhuma viagem em andamento.</td></tr>'}</tbody>
        </table>
      </div></section>` : ""}`;
}
window.loadPage = loadPage;
