// Controle de acesso centralizado. A origem da permissão é SEMPRE a sessão PHP/MySQL.
// Nenhuma página protegida é exibida antes de autenticação, permissão e carregamento.
const PAGE = document.body.dataset.page;
const LABELS = {
  dashboard:'Painel', funcionarios:'Funcionários', veiculos:'Veículos', cargas:'Cargas',
  viagens:'Viagens', abastecimentos:'Abastecimentos', manutencoes:'Manutenções',
  multas:'Multas', usuarios:'Usuários', banco_horas:'Banco de horas',
  criar_usuario:'Criar usuário', relatorios:'Relatórios financeiros',
  agenda:'Minhas viagens', checklist:'Checklist diário', solicitar_manutencao:'Solicitar manutenção',
  alterar_senha:'Trocar senha'
};
const PERMISSIONS = {
  dashboard:{read:['ADMIN','GERENTE','USUARIO','MOTORISTA','RH'],write:[]},
  funcionarios:{read:['ADMIN','GERENTE','RH'],write:['ADMIN','RH']},
  veiculos:{read:['ADMIN','GERENTE','USUARIO'],write:['ADMIN','GERENTE']},
  cargas:{read:['ADMIN','GERENTE','USUARIO'],write:['ADMIN','GERENTE']},
  viagens:{read:['ADMIN','GERENTE','USUARIO','MOTORISTA'],write:['ADMIN','GERENTE']},
  abastecimentos:{read:['ADMIN','GERENTE','MOTORISTA'],write:['ADMIN','GERENTE','MOTORISTA'],writeExisting:['ADMIN','GERENTE']},
  manutencoes:{read:['ADMIN','GERENTE'],write:['ADMIN','GERENTE']},
  multas:{read:['ADMIN','GERENTE','RH'],write:['ADMIN','GERENTE']},
  usuarios:{read:['ADMIN'],write:['ADMIN']},
  criar_usuario:{read:['ADMIN'],write:['ADMIN']},
  banco_horas:{read:['ADMIN','RH'],write:['ADMIN','RH']},
  relatorios:{read:['ADMIN'],write:[]},
  agenda:{read:['MOTORISTA'],write:[]},
  checklist:{read:['MOTORISTA'],write:['MOTORISTA']},
  solicitar_manutencao:{read:['MOTORISTA'],write:['MOTORISTA']},
  alterar_senha:{read:['ADMIN','GERENTE','USUARIO','MOTORISTA','RH'],write:['ADMIN','GERENTE','USUARIO','MOTORISTA','RH']}
};
const NAV = [
  ['Visão geral',['dashboard']],
  ['Operação',['veiculos','cargas','viagens','agenda','abastecimentos','checklist','solicitar_manutencao','manutencoes','multas']],
  ['Gestão',['funcionarios','banco_horas','relatorios','usuarios','alterar_senha']]
];
const ICON_PATHS = {
  dashboard:'M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z',
  veiculos:'M2 5h13v12H2z M15 9h4l3 4v4h-7 M6 17a2 2 0 1 0 0 4 2 2 0 0 0 0-4 M18 17a2 2 0 1 0 0 4 2 2 0 0 0 0-4',
  cargas:'M3 7l9-4 9 4v10l-9 4-9-4zM3 7l9 4 9-4M12 11v10M8 5l9 4',
  viagens:'M4 20L20 4M9 4h11v11',
  agenda:'M3 5h18v16H3zM3 10h18M8 3v4m8-4v4m-8 7h2m4 0h2',
  abastecimentos:'M3 21h13M5 21V4h9v17M5 11h9m0 3h2a2 2 0 0 1 2 2v1a2 2 0 0 0 4 0v-6l-3-3',
  checklist:'M8 5H5v16h14V5h-3M8 3h8v4H8zM8 14l3 3 5-6',
  manutencoes:'M21 5a5 5 0 0 1-6.8 6.8L6 20a2 2 0 0 1-3-3l8.2-8.2A5 5 0 0 1 18 2l-3 3 3 3z',
  multas:'M12 3 2 21h20zM12 9v5m0 3h.01',
  funcionarios:'M16 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2m18 0v-2a4 4 0 0 0-3-3.9M13 7a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0zm3-3a3.3 3.3 0 0 1 0 6.5',
  banco_horas:'M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0zM12 6v6l4 2',
  relatorios:'M3 3v18h18M8 16v-4m5 4V8m5 8V5',
  usuarios:'M12 22s7-3 7-9V5l-7-3-7 3v8c0 6 7 9 7 9zm-3-10 2 2 4-4',
  alterar_senha:'M4 10h16v11H4zM8 10V7a4 4 0 0 1 8 0v3m-4 5v2',
  menu:'M3 6h18M3 12h18M3 18h18'
};
function uiIcon(name){
  const path=ICON_PATHS[name==='solicitar_manutencao'?'manutencoes':name] || ICON_PATHS.dashboard;
  return `<svg class="ui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${path}"/></svg>`;
}
let currentUser=null;
let lookups={};
const $ = selector => document.querySelector(selector);
const normalizeRole = role => String(role ?? '').trim().toUpperCase();
function showToast(message){
  const el=$('#toast');if(!el)return;
  el.textContent=message;el.classList.add('visible');
  setTimeout(()=>el.classList.remove('visible'),4500);
}
function money(value){return Number(value||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});}
function dateValue(value){if(!value)return '';const [date,time]=String(value).split('T');return date.split('-').reverse().join('/')+(time?' '+time:'');}
function escapeHtml(value){return String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function canRead(page){return Boolean(currentUser && PERMISSIONS[page]?.read.includes(currentUser.nivel));}
function canWrite(page){return Boolean(currentUser && PERMISSIONS[page]?.write.includes(currentUser.nivel));}
async function loadLookups(){lookups=await api('lookup');}
function renderNav(){
  const nav=$('.sidebar nav');if(!nav)return;
  nav.id='main-nav';
  nav.setAttribute('aria-label','Menu principal');
  nav.replaceChildren();
  for(const [title,pages] of NAV){
    const visible=pages.filter(canRead);
    if(!visible.length)continue;
    const group=document.createElement('div');
    group.className='nav-group';
    const label=document.createElement('p');
    label.className='nav-label';label.textContent=title;group.append(label);
    for(const page of visible){
      const link=document.createElement('a');
      link.href=page+'.html';link.dataset.pageLink=page;
      link.innerHTML=uiIcon(page);link.append(LABELS[page]);
      if(page===PAGE || (PAGE==='criar_usuario' && page==='usuarios')){
        link.classList.add('active');link.setAttribute('aria-current','page');
      }
      group.append(link);
    }
    nav.append(group);
  }
  const toggle=document.createElement('button');
  toggle.type='button';toggle.className='nav-toggle';toggle.innerHTML=uiIcon('menu')+'Menu';
  toggle.setAttribute('aria-controls',nav.id);
  const setOpen=open=>{
    nav.classList.toggle('is-open',open);
    toggle.setAttribute('aria-expanded',String(open));
  };
  setOpen(false);
  toggle.addEventListener('click',()=>setOpen(!nav.classList.contains('is-open')));
  nav.parentElement.addEventListener('keydown',event=>{
    if(event.key==='Escape' && nav.classList.contains('is-open')){
      setOpen(false);toggle.focus();
    }
  });
  window.matchMedia('(max-width: 900px)').addEventListener('change',()=>setOpen(false));
  nav.before(toggle);
}
function showBlockingMessage(titleText, detailText){
  const layout=document.querySelector('.layout');
  if(layout) layout.remove(); // Conteúdo privilegiado jamais é exibido num estado de erro.
  document.documentElement.classList.remove('auth-pending');
  const existing=document.getElementById('access-message');if(existing)existing.remove();
  const container=document.createElement('main');container.id='access-message';
  container.style.cssText='max-width:600px;margin:8vh auto;padding:26px;background:white;border:1px solid #dce2e7;border-radius:12px;color:#202832;font:15px/1.5 Arial,sans-serif';
  const title=document.createElement('h1');title.textContent=titleText;
  const detail=document.createElement('p');detail.textContent=detailText;
  const links=document.createElement('p');links.style.cssText='display:flex;gap:16px;flex-wrap:wrap';
  for(const [label,url] of [['Tentar novamente',location.pathname+location.search],['Diagnosticar conexão','diagnostico.html'],['Ir para o painel','dashboard.html'],['Entrar novamente','login.html']]){
    const link=document.createElement('a');link.href=url;link.textContent=label;links.appendChild(link);
  }
  container.append(title,detail,links);document.body.prepend(container);
}
async function initializeApp(){
  // A classe auth-pending está no próprio HTML, antes de QUALQUER carregamento externo.
  try{
    const user=await api('me');
    if(!user || !user.nivel || !user.nome){
      throw new Error('A API não retornou um perfil válido. Abra diagnostico.html para verificar a sessão.');
    }
    currentUser={...user,nivel:normalizeRole(user.nivel)};
    if(!PERMISSIONS[PAGE]){
      showBlockingMessage('Página não configurada','A página não possui uma regra de permissão.');return;
    }
    if(!canRead(PAGE)){
      showBlockingMessage('Acesso não autorizado',`O servidor identificou sua permissão como ${currentUser.nivel}. Essa página não está disponível para esse perfil.`);return;
    }
    const userInfo=$('#current-user');
    if(userInfo)userInfo.textContent=`${user.nome} · ${currentUser.nivel}`;
    renderNav();
    $('#logout-button')?.addEventListener('click',async()=>{
      try{await api('logout','POST');}catch(err){console.warn('Falha ao encerrar sessão:',err);}
      finally{location.replace('login.html');}
    });
    if(window.needsLookups)await loadLookups();
    if(typeof window.loadPage==='function')await window.loadPage();
    // Última etapa: só agora revelar o site; nenhuma ação administrativa aparece antes disso.
    document.documentElement.classList.remove('auth-pending');
    const notice=new URLSearchParams(location.search).get('acesso');
    if(notice==='negado')showToast('Você não tem permissão para acessar essa página.');
  }catch(error){
    if(error.status===401 || /sessão expirada/i.test(error.message)){
      location.replace('login.html?motivo=sessao');return;
    }
    showBlockingMessage('Não foi possível carregar esta página', error?.message || 'Falha desconhecida.');
  }
}
document.addEventListener('DOMContentLoaded', initializeApp);
